ATM Process System

The ATM Process System is a Python package that provides the core functionalities of an automated teller machine (ATM). It is designed to simulate basic ATM operations such as withdrawals, deposits, balance inquiries, and transaction management.
Features

User-Friendly Interface: Supports both terminal-based and GUI (using tkinter) interfaces for interaction.
Modular Design: Easily extensible and customizable for additional banking functionalities.
Basic Transactions: Perform essential ATM operations:
Withdraw money
Deposit money
Check account balance

